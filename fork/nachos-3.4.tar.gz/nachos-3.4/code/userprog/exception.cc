// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "../threads/system.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

int stackController[8] ={0};

int findFirstFreeStack()
{
    for (int itr=1;itr<8;itr++) if (stackController[itr]==0) return itr;
    return -1;
}

void ForkHandle(int func)
{
    //machine->DumpState();
    machine->WriteRegister(PCReg, func);
    machine->WriteRegister(NextPCReg, func+4);
    machine->Run();
}
void HaltSysCall(){
    DEBUG('a', "Shutdown, initiated by user program.\n");
    interrupt->Halt();}

void ExitSysCall(){
    printf("The program finished with code %d\n", machine->ReadRegister(4));
    currentThread->freeStack(stackController);
    currentThread->Finish();
}

void ForkSysCall()
{
    machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
    machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    ////////
    int func,flag;
    func = machine->ReadRegister(4);
    flag = machine->ReadRegister(5);
    Thread *child = new Thread("forked thread",currentThread->getPriority()-1);
    printf ("child with priority %d born\n", child->getPriority());
    child->space = currentThread->space;
    ////////// stack
    //child->userStackAllocate(currentThread->getFirstFreeStack());
    child->userStackAllocate(findFirstFreeStack(),stackController);
    /////////
    //machine->DumpState();
    child->Fork(ForkHandle,func);
    if (flag) {printf("hhh\n");currentThread->Yield();}

}

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);

    if (which == SyscallException)  {
        printf("SysCall\n");
        switch (type){
            case SC_Halt:
                HaltSysCall();
                break;
            case SC_Exit:
                ExitSysCall();
                break;
            case SC_Fork:
                ForkSysCall();
                break;


        }

    } else {
	printf("Unexpected user mode exception %d %d\n", which, type);
	ASSERT(FALSE);
    }
}
